<?php
require_once "Conexao.php";

class Categoria
{
    public $id;
    public $nome;
    public $usuario_id;
}