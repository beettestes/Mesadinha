<?php
require_once "Conexao.php";

class Conta
{
    public $id;
    public $nome;
    public $tipo;
    public $categoria_id;
}