<?php
require_once "Conexao.php";

class Movimentacao
{
    public $id;
    public $valor;
    public $data;
    public $conta_id;
    public $usuario_id;
}